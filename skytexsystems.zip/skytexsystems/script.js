document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevents the form from submitting
  
    // Add your code here to handle form submission, e.g., sending an email
  
    // Optionally, you can show a success message to the user
    alert('Message sent successfully!');
  });